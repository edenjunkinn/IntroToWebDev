function calcWordFrequencies() {
   
}