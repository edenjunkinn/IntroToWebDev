window.addEventListener("DOMContentLoaded", domLoaded);

function domLoaded() {
   // TODO: Complete the function
}

function convertCtoF(degreesCelsius) {
   // TODO: Complete the function
}

function convertFtoC(degreesFahrenheit) {
   // TODO: Complete the function
}
