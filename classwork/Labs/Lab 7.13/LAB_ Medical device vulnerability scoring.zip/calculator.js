function updateScore() {
	
}